<?php

$dbServer = "localhost:3306";
$dbUser = "root";
$dbPass = "ziggymysql23";
$dbName = "users";

$conn = mysqli_connect($dbServer, $dbUser, $dbPass, $dbName);

?>